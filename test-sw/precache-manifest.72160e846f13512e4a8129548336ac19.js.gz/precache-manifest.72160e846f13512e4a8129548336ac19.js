self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "710b0f425ae47f22a280",
    "url": "css/app.300a9261.css"
  },
  {
    "revision": "d6ce0f92162400645d71",
    "url": "css/attractions-list.9375d6ce.css"
  },
  {
    "revision": "8fd2e0f5616e0eb0f023",
    "url": "css/attractionsClass.7676e0bf.css"
  },
  {
    "revision": "a621c42fc03743610a96",
    "url": "css/chunk-vendors.be2fa5a5.css"
  },
  {
    "revision": "9f77f4508438f3de67ff",
    "url": "css/class-list.953113cb.css"
  },
  {
    "revision": "bcde5163b1d5bce26fe3",
    "url": "css/customized-travel.8aca845f.css"
  },
  {
    "revision": "831a88cf5357385edd20",
    "url": "css/experience-non-relic.3ed4dee2.css"
  },
  {
    "revision": "dbb7120edc4251ff8779",
    "url": "css/experience-non-relic~list.b658ef5c.css"
  },
  {
    "revision": "736c9253a66d0d4a5be4",
    "url": "css/explanation.a8d5feec.css"
  },
  {
    "revision": "8327ac33bb8ea050dab4",
    "url": "css/exploration-non-relics.cfe888be.css"
  },
  {
    "revision": "bc81cf17b1e95a7bdf23",
    "url": "css/favourite-list.2bcb3187.css"
  },
  {
    "revision": "6757f5e42fbc324744af",
    "url": "css/flower.d7286771.css"
  },
  {
    "revision": "6d42d551e597d40be765",
    "url": "css/foodList.521b4c98.css"
  },
  {
    "revision": "635259fb3e6ad98083ca",
    "url": "css/home.a97f0cea.css"
  },
  {
    "revision": "6ac6b342a7fdb7c310fb",
    "url": "css/home~tool.de61e034.css"
  },
  {
    "revision": "ec50c2b2c323a9525b6f",
    "url": "css/info.7b221628.css"
  },
  {
    "revision": "875bda9f45a664f955fd",
    "url": "css/list-detail.ccf6c8a3.css"
  },
  {
    "revision": "d2a6d9eacb3d659195a9",
    "url": "css/list-detail1.6636a1fd.css"
  },
  {
    "revision": "3ba12fe2101118275c37",
    "url": "css/list-detail~list-detail1.4de69a1c.css"
  },
  {
    "revision": "8341d7f53ff1cfa0327e",
    "url": "css/list.025b1b41.css"
  },
  {
    "revision": "4fe2df9e9d8f53215f74",
    "url": "css/message.158ea73b.css"
  },
  {
    "revision": "f54c01f3fe1bf75e18c6",
    "url": "css/metro.8f120684.css"
  },
  {
    "revision": "45f454def9b7a7acd052",
    "url": "css/order-detail.7f090c45.css"
  },
  {
    "revision": "7236e7a3a1780ecd68df",
    "url": "css/order-list.4a3a1607.css"
  },
  {
    "revision": "6087e3094ad4ab03b63c",
    "url": "css/plan.1fee080a.css"
  },
  {
    "revision": "36b62e5887d51d8e5485",
    "url": "css/questionnaire.7fcf0590.css"
  },
  {
    "revision": "b08ff13b9a98edc05a10",
    "url": "css/search-result.92cab2ce.css"
  },
  {
    "revision": "30f1ecfd0adbd5e81e5b",
    "url": "css/search.b996ba4a.css"
  },
  {
    "revision": "a75d62c9ca4b288cba03",
    "url": "css/submit.1fab0d08.css"
  },
  {
    "revision": "969e653fb9686fdc4d54",
    "url": "css/terms.05708de7.css"
  },
  {
    "revision": "52bb5a02d23585b23e11",
    "url": "css/tool.eae4e3a7.css"
  },
  {
    "revision": "ea31cd5bb59cc61368a4",
    "url": "css/toure-service.3f25ac00.css"
  },
  {
    "revision": "bb2d32241e1b53251ad0",
    "url": "css/travel.3f56b08e.css"
  },
  {
    "revision": "2d10f5b031fefa24fe22",
    "url": "css/video.d9ebd043.css"
  },
  {
    "revision": "3a28346620eb448cf513",
    "url": "css/weather.4b67bc94.css"
  },
  {
    "revision": "4f28bd74fe63d455f5af",
    "url": "css/ziXunDetail.0a75161f.css"
  },
  {
    "revision": "1eefc85bb6d7893e8549",
    "url": "css/zixun.e96add46.css"
  },
  {
    "revision": "d1f642e0b282b8ea39181ef52c7513c7",
    "url": "favicon.ico"
  },
  {
    "revision": "b841a4dcddd86283cb6e5110b05bf2cb",
    "url": "img/Group 11@3x.b841a4dc.png"
  },
  {
    "revision": "3e1c9a22cfc93b20150231b371881362",
    "url": "img/ID.3e1c9a22.png"
  },
  {
    "revision": "64588382f5c1d717465fdbcece947589",
    "url": "img/Rectangle 4@3x.64588382.png"
  },
  {
    "revision": "0c744eb7d93c521cb2f8eb77b493983c",
    "url": "img/explanation-bg@3x.0c744eb7.jpg"
  },
  {
    "revision": "31f081bf88fb9b1d80710dcf014eb263",
    "url": "img/food-bg.31f081bf.png"
  },
  {
    "revision": "df029945bd96fb62808fe2d96d4c5d33",
    "url": "img/help.df029945.png"
  },
  {
    "revision": "288de5c6f25a115634ca01eb408de71a",
    "url": "img/hotel.288de5c6.png"
  },
  {
    "revision": "5d1b42f03c9c62904f098e8b2d24ce7b",
    "url": "img/icon-camera.5d1b42f0.png"
  },
  {
    "revision": "812e50bcd820a39e28327e67ae7433b7",
    "url": "img/icon_QR@3x.812e50bc.png"
  },
  {
    "revision": "18a12a3f90607c4a0ae93bc28cb1adcf",
    "url": "img/icon_call@3x.18a12a3f.png"
  },
  {
    "revision": "1dda175c0ae9257a1a8eca9942a8df14",
    "url": "img/icon_jiaotong@3x.1dda175c.png"
  },
  {
    "revision": "c905a5d5cbee9620561a3af68bcb95ca",
    "url": "img/icon_jiudian.c905a5d5.png"
  },
  {
    "revision": "e18351841920cb80ba7acc142daa6810",
    "url": "img/icon_lock@3x.e1835184.png"
  },
  {
    "revision": "a9886f03ce68b982f600e08cd46cc076",
    "url": "img/icon_lvyou@3x.a9886f03.png"
  },
  {
    "revision": "330baf382e19e2932bc4ccffc2b3c9d6",
    "url": "img/icon_lyfw.330baf38.png"
  },
  {
    "revision": "ea09d6d195c0bd5e170c6a02f846440c",
    "url": "img/icon_lyfw@3x.ea09d6d1.png"
  },
  {
    "revision": "ac1a085294385f1263e46087259e8846",
    "url": "img/icon_meishi.ac1a0852.png"
  },
  {
    "revision": "6da7bba56f87c2bb0385777f0cd0f175",
    "url": "img/icon_menpiao.6da7bba5.png"
  },
  {
    "revision": "2bdef19a17e5e56a7ee80c0799fd3147",
    "url": "img/icon_notice.2bdef19a.png"
  },
  {
    "revision": "2d64b6a4d3a82c7b4a5a5a68dd4a2812",
    "url": "img/icon_scan@3x.2d64b6a4.png"
  },
  {
    "revision": "7963a2b4cbd612bd78391e43998fb42d",
    "url": "img/icon_scrollTop.7963a2b4.png"
  },
  {
    "revision": "492c66317f948ed198fe7c8ef56f6948",
    "url": "img/icon_transfer@3x.492c6631.png"
  },
  {
    "revision": "ca2285ff8aab1a6ac748a22c923c382e",
    "url": "img/icon_wifi@3x.ca2285ff.png"
  },
  {
    "revision": "1264b89f067613d8079ba71249d52026",
    "url": "img/icon_yjbj.1264b89f.png"
  },
  {
    "revision": "e09f4cbaa824ce8e2cab22dfb0984553",
    "url": "img/icon_yjbj@3x.e09f4cba.png"
  },
  {
    "revision": "722514fc17a4dd3a6bda744d9504ac83",
    "url": "img/icon_yjts.722514fc.png"
  },
  {
    "revision": "fefcb1d3a442aeed0126dd03467422a9",
    "url": "img/icon_yjts@3x.fefcb1d3.png"
  },
  {
    "revision": "c714b989eb950d69e78dc3d4b23552aa",
    "url": "img/icon_yljz@3x.c714b989.png"
  },
  {
    "revision": "92885b3b35c0c6dc6118fe752f5df151",
    "url": "img/icon_zixun.92885b3b.png"
  },
  {
    "revision": "f130a0b70e386170cf6f011c0ca8c4f4",
    "url": "img/icons/android-chrome-192x192.png"
  },
  {
    "revision": "0ff1bc4d14e5c9abcacba7c600d97814",
    "url": "img/icons/android-chrome-512x512.png"
  },
  {
    "revision": "936d6e411cabd71f0e627011c3f18fe2",
    "url": "img/icons/apple-touch-icon-120x120.png"
  },
  {
    "revision": "1a034e64d80905128113e5272a5ab95e",
    "url": "img/icons/apple-touch-icon-152x152.png"
  },
  {
    "revision": "c43cd371a49ee4ca17ab3a60e72bdd51",
    "url": "img/icons/apple-touch-icon-180x180.png"
  },
  {
    "revision": "9a2b5c0f19de617685b7b5b42464e7db",
    "url": "img/icons/apple-touch-icon-60x60.png"
  },
  {
    "revision": "af28d69d59284dd202aa55e57227b11b",
    "url": "img/icons/apple-touch-icon-76x76.png"
  },
  {
    "revision": "66830ea6be8e7e94fb55df9f7b778f2e",
    "url": "img/icons/apple-touch-icon.png"
  },
  {
    "revision": "4bb1a55479d61843b89a2fdafa7849b3",
    "url": "img/icons/favicon-16x16.png"
  },
  {
    "revision": "98b614336d9a12cb3f7bedb001da6fca",
    "url": "img/icons/favicon-32x32.png"
  },
  {
    "revision": "b89032a4a5a1879f30ba05a13947f26f",
    "url": "img/icons/msapplication-icon-144x144.png"
  },
  {
    "revision": "058a3335d15a3eb84e7ae3707ba09620",
    "url": "img/icons/mstile-150x150.png"
  },
  {
    "revision": "f22d501a35a87d9f21701cb031f6ea17",
    "url": "img/icons/safari-pinned-tab.svg"
  },
  {
    "revision": "3b0c10d43e0a6f70279837cb4c93eca0",
    "url": "img/img_zixun.3b0c10d4.jpg"
  },
  {
    "revision": "6cbdb8e3a39b21c5c7b1113dd6eafcf2",
    "url": "img/logo.6cbdb8e3.png"
  },
  {
    "revision": "c95a2bf39040eaaba332446cc4ea92e8",
    "url": "img/map.c95a2bf3.png"
  },
  {
    "revision": "283f1bc8247d57a443aa044baec440b8",
    "url": "img/money@3x.283f1bc8.png"
  },
  {
    "revision": "07b585f770e06209b8fbeaf69e11a867",
    "url": "img/nine_1.07b585f7.jpg"
  },
  {
    "revision": "09315864d85e7b9808cbeded86ca75e0",
    "url": "img/nine_2.09315864.jpg"
  },
  {
    "revision": "3f67cd56228af64c44c8cb5d3564a1e1",
    "url": "img/nine_3.3f67cd56.jpg"
  },
  {
    "revision": "6e8bb03eb0dc23c4b75c0038a18b1521",
    "url": "img/nine_4.6e8bb03e.jpg"
  },
  {
    "revision": "b39a83278666a2e921d800d253b1c5fd",
    "url": "img/nine_5.b39a8327.jpg"
  },
  {
    "revision": "8aae0c272f664de940d04ea9ad2ba536",
    "url": "img/nine_6.8aae0c27.jpg"
  },
  {
    "revision": "a8d4b275c864094651748248831fc9a2",
    "url": "img/nine_7.a8d4b275.jpg"
  },
  {
    "revision": "588e2feb4daefd4a6422cd6a10955144",
    "url": "img/nine_8.588e2feb.jpg"
  },
  {
    "revision": "0e5f46dcb8bf87e32d0742a272972ef5",
    "url": "img/nine_9.0e5f46dc.jpg"
  },
  {
    "revision": "dace6754ae8c83117f0e1cd656eba3c1",
    "url": "img/no_message@3x.dace6754.png"
  },
  {
    "revision": "6317e10ab88695947d05dd8a35139670",
    "url": "img/no_order.6317e10a.png"
  },
  {
    "revision": "e5cf49a82286c23b0ef3edd6afadb1f8",
    "url": "img/no_records.e5cf49a8.png"
  },
  {
    "revision": "22da315ad9b5f6f8c35ab7ee9a9962cd",
    "url": "img/no_search_found.22da315a.png"
  },
  {
    "revision": "acc526b680342b6f43b02d73ec43f381",
    "url": "img/play.acc526b6.png"
  },
  {
    "revision": "c69bad9476057d96b23c0993d90a759e",
    "url": "img/play@3x.c69bad94.png"
  },
  {
    "revision": "cd5c56195dfb8ef5e8b0d7680fb6a329",
    "url": "img/promo_en-US.cd5c5619.png"
  },
  {
    "revision": "06c65a3ff09bf8616fd85ed732518cd9",
    "url": "img/promo_zh-CN.06c65a3f.png"
  },
  {
    "revision": "936b449743d908d034c24aa36014db79",
    "url": "img/rectangle.936b4497.png"
  },
  {
    "revision": "cba64c6711d9b41f5c6d7b20ea5ef94f",
    "url": "img/renzheng@3x.cba64c67.png"
  },
  {
    "revision": "c2d6210cf14ca9b375f5a499f1290e52",
    "url": "img/right.c2d6210c.png"
  },
  {
    "revision": "b36f16b7147d52aafe29fbcd0c881391",
    "url": "img/rolling.b36f16b7.svg"
  },
  {
    "revision": "e0d2580e8a851107f53508f97c4cf992",
    "url": "img/sprite.e0d2580e.png"
  },
  {
    "revision": "a9886f03ce68b982f600e08cd46cc076",
    "url": "img/tailor.a9886f03.png"
  },
  {
    "revision": "30085a8ee59b6af22697cfed0254268e",
    "url": "img/take_photo@3x.30085a8e.png"
  },
  {
    "revision": "751c42eda2989d3d5eb0f1c5ccdd41d1",
    "url": "img/tool.751c42ed.png"
  },
  {
    "revision": "bf5fecb9f9d6c967e0cb238002be173b",
    "url": "img/tool_clear_bg.bf5fecb9.png"
  },
  {
    "revision": "7793a866b477bb10f991ca025dab6266",
    "url": "img/tour-service.7793a866.png"
  },
  {
    "revision": "8fd265cd48577d9b4da5f79a48b9f6a1",
    "url": "img/trans_cn@3x.8fd265cd.png"
  },
  {
    "revision": "a9aff5894bc110812baa87bcd4f512ab",
    "url": "img/trans_en@3x.a9aff589.png"
  },
  {
    "revision": "1dda175c0ae9257a1a8eca9942a8df14",
    "url": "img/transport.1dda175c.png"
  },
  {
    "revision": "c305b67328b0066a8cab5910b6451122",
    "url": "img/user_code.c305b673.png"
  },
  {
    "revision": "89cc9f2f828442d1af585dc96968a5ca",
    "url": "img/video.89cc9f2f.jpg"
  },
  {
    "revision": "fa53944ab6271c6514615c81ac6de8c4",
    "url": "img/wode@3x.fa53944a.png"
  },
  {
    "revision": "b997a429305c41d8144c78f0a06e0415",
    "url": "img/zhibo.b997a429.jpg"
  },
  {
    "revision": "87bfff731d1376d2150e669afba163c7",
    "url": "img/zixun@3x.87bfff73.png"
  },
  {
    "revision": "c2d6210cf14ca9b375f5a499f1290e52",
    "url": "img/分组 2@3x.c2d6210c.png"
  },
  {
    "revision": "16c4ce1faa00697895da37b3d97a3b04",
    "url": "index.html"
  },
  {
    "revision": "710b0f425ae47f22a280",
    "url": "js/app.2eaccd44.js"
  },
  {
    "revision": "d6ce0f92162400645d71",
    "url": "js/attractions-list.f1f2d18d.js"
  },
  {
    "revision": "d22600549d6116fd30ef",
    "url": "js/attractions-list~order-list~search-result.ffad74bd.js"
  },
  {
    "revision": "8fd2e0f5616e0eb0f023",
    "url": "js/attractionsClass.a7e33f95.js"
  },
  {
    "revision": "a621c42fc03743610a96",
    "url": "js/chunk-vendors.03cca22d.js"
  },
  {
    "revision": "9f77f4508438f3de67ff",
    "url": "js/class-list.d113cad8.js"
  },
  {
    "revision": "bcde5163b1d5bce26fe3",
    "url": "js/customized-travel.c2586971.js"
  },
  {
    "revision": "97d7ffb3b538c8a31bb5",
    "url": "js/exhibitionHal.bf7920fe.js"
  },
  {
    "revision": "831a88cf5357385edd20",
    "url": "js/experience-non-relic.c06de22d.js"
  },
  {
    "revision": "dbb7120edc4251ff8779",
    "url": "js/experience-non-relic~list.59e6acad.js"
  },
  {
    "revision": "736c9253a66d0d4a5be4",
    "url": "js/explanation.2febb49b.js"
  },
  {
    "revision": "8327ac33bb8ea050dab4",
    "url": "js/exploration-non-relics.5e93132a.js"
  },
  {
    "revision": "bc81cf17b1e95a7bdf23",
    "url": "js/favourite-list.23eecea6.js"
  },
  {
    "revision": "6757f5e42fbc324744af",
    "url": "js/flower.48690f62.js"
  },
  {
    "revision": "6d42d551e597d40be765",
    "url": "js/foodList.4a24460a.js"
  },
  {
    "revision": "635259fb3e6ad98083ca",
    "url": "js/home.d9bb7ea0.js"
  },
  {
    "revision": "6ac6b342a7fdb7c310fb",
    "url": "js/home~tool.6e4de8b4.js"
  },
  {
    "revision": "ec50c2b2c323a9525b6f",
    "url": "js/info.ac3c6507.js"
  },
  {
    "revision": "875bda9f45a664f955fd",
    "url": "js/list-detail.dba99f51.js"
  },
  {
    "revision": "d2a6d9eacb3d659195a9",
    "url": "js/list-detail1.9c8651d7.js"
  },
  {
    "revision": "3ba12fe2101118275c37",
    "url": "js/list-detail~list-detail1.f62bf9c9.js"
  },
  {
    "revision": "8341d7f53ff1cfa0327e",
    "url": "js/list.14a4771e.js"
  },
  {
    "revision": "4fe2df9e9d8f53215f74",
    "url": "js/message.15811b6b.js"
  },
  {
    "revision": "f54c01f3fe1bf75e18c6",
    "url": "js/metro.5e47ff76.js"
  },
  {
    "revision": "45f454def9b7a7acd052",
    "url": "js/order-detail.18340039.js"
  },
  {
    "revision": "7236e7a3a1780ecd68df",
    "url": "js/order-list.089d65d3.js"
  },
  {
    "revision": "6087e3094ad4ab03b63c",
    "url": "js/plan.aa3e69c3.js"
  },
  {
    "revision": "36b62e5887d51d8e5485",
    "url": "js/questionnaire.a777df8f.js"
  },
  {
    "revision": "b08ff13b9a98edc05a10",
    "url": "js/search-result.f7224b8d.js"
  },
  {
    "revision": "30f1ecfd0adbd5e81e5b",
    "url": "js/search.c94503b3.js"
  },
  {
    "revision": "a75d62c9ca4b288cba03",
    "url": "js/submit.e8aa748b.js"
  },
  {
    "revision": "969e653fb9686fdc4d54",
    "url": "js/terms.cc239402.js"
  },
  {
    "revision": "52bb5a02d23585b23e11",
    "url": "js/tool.bc31e206.js"
  },
  {
    "revision": "ea31cd5bb59cc61368a4",
    "url": "js/toure-service.013d3d30.js"
  },
  {
    "revision": "bb2d32241e1b53251ad0",
    "url": "js/travel.bc8ddf69.js"
  },
  {
    "revision": "2d10f5b031fefa24fe22",
    "url": "js/video.91a5c319.js"
  },
  {
    "revision": "3a28346620eb448cf513",
    "url": "js/weather.5dc36e35.js"
  },
  {
    "revision": "4f28bd74fe63d455f5af",
    "url": "js/ziXunDetail.c6dcbcf8.js"
  },
  {
    "revision": "1eefc85bb6d7893e8549",
    "url": "js/zixun.25df9d9b.js"
  },
  {
    "revision": "c66ebc9f7fb3254512304f1e90dee965",
    "url": "privacy-en.html"
  },
  {
    "revision": "11c7412d3af31730735dee9705212954",
    "url": "privacy-zh.html"
  },
  {
    "revision": "93afeffdc834b2446025c0e727db9a61",
    "url": "terms-en.html"
  },
  {
    "revision": "c1fff00642cff3525bee2ad53bb1b7e3",
    "url": "terms-zh.html"
  }
]);